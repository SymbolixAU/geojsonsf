library(testthat)
library(vapour)

test_check("vapour")
