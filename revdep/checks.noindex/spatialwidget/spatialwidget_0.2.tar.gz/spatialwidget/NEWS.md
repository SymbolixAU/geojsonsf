# spatialwidget 0.2

* Allow list palettes
* Removed `data_types` parameter
* Added a `NEWS.md` file to track changes to the package.
