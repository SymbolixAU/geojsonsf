// #include <Rcpp.h>
//
// #include "geojsonsf/geojsonsf.h"
// #include "geojsonsf/utils/utils.hpp"
// #include "geojsonsf/writers/writers.hpp"
//
// template< typename Writer >
// void make_gc_type(Writer& writer, Rcpp::List& sfg,
//                          std::string& geom_type, Rcpp::CharacterVector& cls) {
//
//   bool isnull = false;
//
//   for (Rcpp::List::iterator it = sfg.begin(); it != sfg.end(); it++) {
//
//     switch( TYPEOF( *it ) ) {
//     case VECSXP: {
//       Rcpp::List tmp = Rcpp::as< Rcpp::List >(*it);
//       if (!Rf_isNull(tmp.attr("class"))) {
//
//         cls = tmp.attr("class");
//         // TODO: error handle (there should aways be 3 elements as we're workgin wtih sfg objects)
//         geom_type = cls[1];
//
//         SEXP tst = *it;
//         isnull = geojsonsf::utils::is_null_geometry( tst, geom_type );
//         if ( isnull ) {
//           //writer.Null();
//         } else {
//           geojsonsf::writers::begin_geojson_geometry(writer, geom_type);
//           spatialwidget::geojson::write_geojson(writer, tmp, geom_type, cls);
//           geojsonsf::writers::end_geojson_geometry(writer, geom_type);
//         }
//       } else {
//         make_gc_type(writer, tmp, geom_type, cls);
//       }
//       break;
//     }
//     case REALSXP: {
//       Rcpp::NumericVector tmp = Rcpp::as< Rcpp::NumericVector >( *it );
//       if (!Rf_isNull(tmp.attr("class"))) {
//
//         cls = tmp.attr("class");
//         geom_type = cls[1];
//
//         SEXP tst = *it;
//         isnull = geojsonsf::utils::is_null_geometry( tst, geom_type );
//         if ( isnull ) {
//           //writer.Null();
//         } else {
//           geojsonsf::writers::begin_geojson_geometry(writer, geom_type);
//           spatialwidget::geojson::write_geojson(writer, tmp, geom_type, cls);
//           geojsonsf::writers::end_geojson_geometry(writer, geom_type);
//         }
//       }
//       break;
//     }
//     default: {
//       Rcpp::stop("Coordinates could not be found");
//     }
//     }
//   }
// }
