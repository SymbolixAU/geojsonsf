library(testthat)
library(echor)
test_check("echor")
