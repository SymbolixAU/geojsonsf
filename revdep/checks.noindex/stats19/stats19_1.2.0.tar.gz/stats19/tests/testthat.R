library(testthat)
library(stats19)

test_check("stats19")
