library(testthat)
library(otpr)

test_check("otpr")
