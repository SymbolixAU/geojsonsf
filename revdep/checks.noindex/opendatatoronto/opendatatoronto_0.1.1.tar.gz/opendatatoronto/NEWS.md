# opendatatoronto 0.1.1

* Imported functions from readxl and xml2 to supress R CMD check note
* Fixed a vignette to filter for a given resource before attempting to get it (in a package that previously only had one resource, and therefore didn't need filtering) 

# opendatatoronto 0.1.0

* Initial CRAN release.
