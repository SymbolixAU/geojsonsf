library(testthat)
library(opendatatoronto)

test_check("opendatatoronto")
