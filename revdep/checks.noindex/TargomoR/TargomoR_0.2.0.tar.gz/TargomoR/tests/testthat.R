library(testthat)
library(TargomoR)

test_check("TargomoR")
